import {
  User,
  Lesson,
  SummaryData,
  Flashcard,
  QuizQuestion,
  QuizSubmission,
  QuizResult,
  ChatMessage,
  UploadResponse,
  ContextChunk,
  TutorMode,
  SmartContextData,
} from "../types";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api";

const MOCK_CONTEXTS: Record<string, SmartContextData> = {
  "lesson-poisson": {
    lessonId: "lesson-poisson",
    tokenUsed: 482,
    tokenLimit: 4000,
    latencyMs: 42,
    guardrailActive: true,
    chunks: [
      {
        id: "chunk-poisson-1",
        lessonId: "lesson-poisson",
        title: "Chunk #01 • Định nghĩa & Điều kiện",
        content: "Phân phối Poisson mô tả số lần một sự kiện xảy ra trong một khoảng thời gian hoặc không gian cố định. Điều kiện tiên quyết: các sự kiện phải xảy ra độc lập và tốc độ trung bình λ (lambda) không đổi.",
        similarityScore: 0.94,
        source: "Slide 4 (PDF Giáo trình)",
        charCount: 198,
      },
      {
        id: "chunk-poisson-2",
        lessonId: "lesson-poisson",
        title: "Chunk #02 • Công thức & Kỳ vọng",
        content: "Công thức xác suất: P(X = k) = (e^(-λ) * λ^k) / k!. Trong đó e là số Euler (~2.71828), k là số lần xuất hiện (k = 0, 1, 2...). Đặc điểm quan trọng: Kỳ vọng E(X) = λ và Phương sai Var(X) = λ.",
        similarityScore: 0.89,
        source: "Slide 5 (PDF Giáo trình)",
        charCount: 220,
      },
      {
        id: "chunk-poisson-3",
        lessonId: "lesson-poisson",
        title: "Chunk #03 • Ví dụ thực tế & Lưu ý",
        content: "Ví dụ: Trung bình một tổng đài nhận 6 cuộc gọi mỗi phút (λ = 6). Tính xác suất để đúng 3 cuộc gọi tới trong phút kế tiếp. Lưu ý của giảng viên: Tuyệt đối không áp dụng Poisson khi các sự kiện có tương quan hoặc phụ thuộc nhau!",
        similarityScore: 0.76,
        source: "Transcript Audio 04:12",
        charCount: 215,
      },
    ],
  },
};

// --- MOCK DATA FOR SEAMLESS DEMO / OFFLINE BACKEND FALLBACK ---
const MOCK_LESSONS: Lesson[] = [
  {
    id: "lesson-poisson",
    title: "Xác suất thống kê — Phân phối Poisson & Ứng dụng",
    description: "Mô hình xác suất biến cố ngẫu nhiên độc lập trong khoảng cố định với tham số λ (lambda), công thức và ví dụ thực tế.",
    topic: "Xác suất thống kê",
    documentName: "xac-suat-thong-ke-poisson.pdf",
    documentSize: "1.8 MB",
    documentType: "application/pdf",
    createdAt: "2026-10-02T09:00:00Z",
    updatedAt: "2026-10-02T10:00:00Z",
    flashcardCount: 4,
    quizQuestionCount: 3,
    hasSummary: true,
    status: "ready",
  },
  {
    id: "lesson-1",
    title: "Cơ sở dữ liệu nâng cao - B-Tree & Indexing",
    description: "Tìm hiểu cấu trúc cây B-Tree, cơ chế đánh chỉ mục trong RDBMS và tối ưu hóa câu truy vấn SQL.",
    topic: "Cơ sở dữ liệu",
    documentName: "he-co-so-du-lieu-chapter-4.pdf",
    documentSize: "2.4 MB",
    documentType: "application/pdf",
    createdAt: "2026-09-28T08:30:00Z",
    updatedAt: "2026-09-29T10:15:00Z",
    flashcardCount: 8,
    quizQuestionCount: 5,
    hasSummary: true,
    status: "ready",
  },
  {
    id: "lesson-2",
    title: "Trí tuệ nhân tạo - Thuật toán A* & Tìm kiếm heuristic",
    description: "Nguyên lý tìm đường đi tối ưu với hàm đánh giá f(n) = g(n) + h(n) và tính chất admissible.",
    topic: "Trí tuệ nhân tạo",
    documentName: "ai-search-algorithms.docx",
    documentSize: "1.1 MB",
    documentType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    createdAt: "2026-09-29T14:20:00Z",
    updatedAt: "2026-09-30T09:00:00Z",
    flashcardCount: 6,
    quizQuestionCount: 4,
    hasSummary: true,
    status: "ready",
  },
  {
    id: "lesson-3",
    title: "Mạng máy tính - Giao thức TCP/IP & 3-way Handshake",
    description: "Cơ chế thiết lập và giải phóng liên kết tin cậy, điều khiển luồng (Flow Control) và kiểm soát tắc nghẽn (Congestion Control).",
    topic: "Mạng máy tính",
    documentName: "computer-networks-transport.pdf",
    documentSize: "3.7 MB",
    documentType: "application/pdf",
    createdAt: "2026-10-01T11:00:00Z",
    updatedAt: "2026-10-01T11:00:00Z",
    flashcardCount: 10,
    quizQuestionCount: 6,
    hasSummary: true,
    status: "ready",
  },
];

const MOCK_SUMMARIES: Record<string, SummaryData> = {
  "lesson-poisson": {
    lessonId: "lesson-poisson",
    overview: "Phân phối Poisson là mô hình xác suất rời rạc quan trọng mô tả số lần một sự kiện xảy ra trong một khoảng cố định (thời gian, không gian, diện tích), với điều kiện các sự kiện phải độc lập và tốc độ trung bình λ không đổi.",
    keyPoints: [
      "Điều kiện tiên quyết: Biến cố xảy ra hoàn toàn ngẫu nhiên và độc lập, tốc độ xảy ra trung bình λ là hằng số.",
      "Công thức tính xác suất: P(X = k) = (e^(-λ) * λ^k) / k! với k = 0, 1, 2...",
      "Tính chất đặc biệt: Cả Kỳ vọng E(X) và Phương sai Var(X) đều bằng chính tham số λ.",
      "Ứng dụng xấp xỉ: Dùng để xấp xỉ phân phối Nhị thức B(n, p) khi n rất lớn (n > 50) và p rất nhỏ (p < 0.05)."
    ],
    takeaways: [
      "Luôn kiểm tra giả định 'độc lập' trước khi áp dụng Poisson vào bài toán.",
      "Nếu các sự kiện dồn toa hoặc phụ thuộc (ví dụ đường trơn gây té dồn xe) thì tuyệt đối không dùng Poisson.",
      "Nắm chắc công thức để giải quyết bài toán đếm cuộc gọi tổng đài, lỗi in ấn và lưu lượng mạng."
    ],
    mindmapOutline: [
      "1. Tổng quan Phân phối Poisson -> Biến ngẫu nhiên rời rạc",
      "  1.1. Điều kiện áp dụng -> Biến cố độc lập, tốc độ λ không đổi",
      "  1.2. Công thức cốt lõi -> P(X = k) = e^(-λ) * λ^k / k!",
      "2. Đặc trưng số học -> Kỳ vọng E(X) = λ, Phương sai Var(X) = λ",
      "3. Ứng dụng & Bài toán thi cử -> Xấp xỉ Nhị thức B(n, p), lưu lượng tổng đài"
    ],
    generatedAt: "2026-10-02T10:00:00Z",
  },
  "lesson-1": {
    lessonId: "lesson-1",
    overview: "Tài liệu phân tích chuyên sâu về cách các hệ quản trị cơ sở dữ liệu (RDBMS như PostgreSQL, MySQL, SQL Server) tổ chức dữ liệu đĩa thông qua B-Tree Index nhằm giảm thiểu chi phí I/O.",
    keyPoints: [
      "B-Tree là cây tìm kiếm tự cân bằng nhiều nhánh, bảo đảm độ phức tạp tìm kiếm, chèn và xóa luôn ở mức O(log N).",
      "Clustered Index sắp xếp vật lý dữ liệu trên đĩa theo khóa chính, mỗi bảng chỉ có duy nhất 1 Clustered Index.",
      "Non-Clustered Index lưu cấu trúc trỏ về con trỏ bản ghi (RID hoặc Clustering Key), cho phép tạo nhiều chỉ mục trên cùng một bảng.",
      "Index Scan vs Index Seek: Seek truy xuất trực tiếp các khối đĩa mục tiêu, trong khi Scan phải duyệt qua toàn bộ cây chỉ mục."
    ],
    takeaways: [
      "Tránh lạm dụng index trên các bảng có tần suất INSERT/UPDATE cao vì chi phí bảo trì index rất tốn kém.",
      "Quy tắc tiền tố bên trái (Left-Prefix Rule) áp dụng bắt buộc đối với Composite Indexes.",
      "Thường xuyên kiểm tra Execution Plan (EXPLAIN ANALYZE) để phát hiện Missing Index."
    ],
    mindmapOutline: [
      "1. Tổng quan Indexing -> Động lực giảm I/O đĩa",
      "2. Cấu trúc B-Tree / B+Tree -> Node gốc, Node nhánh, Node lá kết nối đôi",
      "3. Phân loại Index -> Clustered vs Non-Clustered",
      "4. Chiến lược tối ưu -> Composite Index, Index Covering, Rebuild Index"
    ],
    generatedAt: "2026-09-29T10:15:00Z",
  },
};

const MOCK_FLASHCARDS: Record<string, Flashcard[]> = {
  "lesson-poisson": [
    {
      id: "fc-p-1",
      lessonId: "lesson-poisson",
      term: "Điều kiện áp dụng phân phối Poisson là gì?",
      definition: "Các biến cố phải xảy ra độc lập với nhau và tốc độ trung bình λ (lambda) không đổi theo thời gian.",
      category: "Điều kiện tiên quyết",
      difficulty: "easy",
      isMastered: false,
    },
    {
      id: "fc-p-2",
      lessonId: "lesson-poisson",
      term: "Công thức tính xác suất P(X = k) của Poisson?",
      definition: "P(X = k) = (e^(-λ) * λ^k) / k! (với e ≈ 2.71828 và k = 0, 1, 2...).",
      category: "Công thức toán học",
      difficulty: "medium",
      isMastered: false,
    },
    {
      id: "fc-p-3",
      lessonId: "lesson-poisson",
      term: "Kỳ vọng E(X) và Phương sai Var(X) bằng bao nhiêu?",
      definition: "Trong phân phối Poisson, cả Kỳ vọng E(X) và Phương sai Var(X) đều bằng chính tham số λ.",
      category: "Tính chất đặc trưng",
      difficulty: "medium",
      isMastered: true,
    },
    {
      id: "fc-p-4",
      lessonId: "lesson-poisson",
      term: "Khi nào xấp xỉ Nhị thức B(n, p) sang Poisson?",
      definition: "Khi số phép thử n rất lớn (n > 50) và xác suất p rất nhỏ (p < 0.05) sao cho tích np = λ = hằng số.",
      category: "Nâng cao & Đề thi",
      difficulty: "hard",
      isMastered: false,
    },
  ],
  "lesson-1": [
    {
      id: "fc-1",
      lessonId: "lesson-1",
      term: "B-Tree (Balanced Tree)",
      definition: "Cấu trúc dữ liệu cây tự cân bằng cho phép lưu trữ nhiều khóa trong mỗi nút và duy trì dữ liệu được sắp xếp, tối ưu cho việc đọc/ghi các khối dữ liệu lớn trên bộ nhớ phụ.",
      category: "Cấu trúc dữ liệu",
      difficulty: "medium",
      isMastered: false,
    },
    {
      id: "fc-2",
      lessonId: "lesson-1",
      term: "Clustered Index",
      definition: "Chỉ mục quyết định thứ tự lưu trữ vật lý của các dòng dữ liệu trong bảng. Một bảng chỉ có thể có đúng một Clustered Index (thường là Primary Key).",
      category: "Cơ sở dữ liệu",
      difficulty: "easy",
      isMastered: true,
    },
    {
      id: "fc-3",
      lessonId: "lesson-1",
      term: "Covering Index",
      definition: "Chỉ mục chứa đầy đủ tất cả các cột được yêu cầu trong câu lệnh SELECT và WHERE, giúp Database Engine không cần thực hiện Look-up vào bảng gốc.",
      category: "Tối ưu hóa",
      difficulty: "hard",
      isMastered: false,
    },
    {
      id: "fc-4",
      lessonId: "lesson-1",
      term: "Page Split",
      definition: "Hiện tượng xảy ra khi thêm dữ liệu mới vào một trang dữ liệu đã đầy trong chỉ mục, hệ thống phải cấp phát trang mới và chia đôi dữ liệu, gây phân mảnh.",
      category: "Lưu trữ",
      difficulty: "hard",
      isMastered: false,
    },
  ],
};

const MOCK_QUIZZES: Record<string, QuizQuestion[]> = {
  "lesson-poisson": [
    {
      id: "q-p-1",
      lessonId: "lesson-poisson",
      question: "Cho biến ngẫu nhiên X ~ Poisson(λ = 5). Phương sai Var(X) bằng bao nhiêu?",
      options: ["25", "5", "√5", "0"],
      correctIndex: 1,
      explanation: "Đặc trưng then chốt của phân phối Poisson là Phương sai Var(X) luôn bằng Kỳ vọng E(X) = λ = 5.",
    },
    {
      id: "q-p-2",
      lessonId: "lesson-poisson",
      question: "Trường hợp nào dưới đây KHÔNG được phép sử dụng phân phối Poisson?",
      options: [
        "Đếm số cuộc gọi đến tổng đài độc lập mỗi phút",
        "Đếm số lỗi chính tả ngẫu nhiên trên 1 trang sách",
        "Đếm số xe trượt té dồn toa do trời mưa đường trơn (các xe phụ thuộc nhau)",
        "Đếm số lượt truy cập server ngẫu nhiên trong giờ thấp điểm",
      ],
      correctIndex: 2,
      explanation: "Điều kiện tiên quyết của Poisson là các sự kiện phải hoàn toàn độc lập. Khi trời mưa làm trượt té dồn toa, sự kiện sau phụ thuộc vào sự kiện trước nên vi phạm giả định.",
    },
    {
      id: "q-p-3",
      lessonId: "lesson-poisson",
      question: "Công thức tính xác suất P(X = 0) khi λ = 3 là biểu thức nào?",
      options: ["e^(-3)", "3 * e^(-3)", "0", "1 - e^(-3)"],
      correctIndex: 0,
      explanation: "Thế k = 0 vào công thức Poisson: P(X=0) = (e^(-3) * 3^0) / 0! = e^(-3) * 1 / 1 = e^(-3).",
    },
  ],
  "lesson-1": [
    {
      id: "q-1",
      lessonId: "lesson-1",
      question: "Một bảng cơ sở dữ liệu quan hệ có thể có tối đa bao nhiêu Clustered Index?",
      options: ["Không giới hạn", "Tối đa 249", "Duy nhất 1", "Tối đa 16"],
      correctIndex: 2,
      explanation: "Do Clustered Index sắp xếp trực tiếp vị trí vật lý của dữ liệu trên đĩa, nên một bảng chỉ có thể có đúng 1 thứ tự vật lý duy nhất.",
    },
    {
      id: "q-2",
      lessonId: "lesson-1",
      question: "Độ phức tạp thời gian trung bình để tìm kiếm một bản ghi trong B-Tree là gì?",
      options: ["O(1)", "O(log N)", "O(N)", "O(N log N)"],
      correctIndex: 1,
      explanation: "B-Tree là cây tự cân bằng với chiều cao h = O(log N), do đó thao tác tìm kiếm, chèn, xóa đều có độ phức tạp O(log N).",
    },
    {
      id: "q-3",
      lessonId: "lesson-1",
      question: "Khi nào việc đánh chỉ mục (Indexing) có thể làm giảm hiệu năng hệ thống?",
      options: [
        "Khi bảng có quá nhiều câu lệnh SELECT phức tạp",
        "Khi bảng chịu tải INSERT, UPDATE, DELETE với tần suất rất cao",
        "Khi cơ sở dữ liệu sử dụng bộ nhớ SSD",
        "Khi bảng có nhiều hơn 100.000 bản ghi",
      ],
      correctIndex: 1,
      explanation: "Mỗi thao tác INSERT/UPDATE/DELETE đều phải cập nhật lại tất cả các cây chỉ mục liên quan, gây nghẽn I/O nếu tần suất ghi quá lớn.",
    },
  ],
};

// Helper fetch with error handling and fallback
async function safeFetch<T>(endpoint: string, options?: RequestInit, fallbackData?: T): Promise<T> {
  const url = `${BASE_URL}${endpoint}`;
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000); // 6s timeout

    const res = await fetch(url, {
      ...options,
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        ...(options?.headers || {}),
      },
    });

    clearTimeout(timeoutId);

    if (!res.ok) {
      const errText = await res.text().catch(() => "");
      throw new Error(`API Error ${res.status}: ${errText || res.statusText}`);
    }

    return await res.json();
  } catch (error: any) {
    console.warn(`[API] Gọi Backend ${endpoint} không thành công (${error.message}).`);
    if (fallbackData !== undefined) {
      console.info(`[API] Sử dụng Mock Data dự phòng cho ${endpoint}.`);
      return fallbackData;
    }
    throw error;
  }
}

export const apiService = {
  // Auth
  async login(credentials: { email: string; password: string }): Promise<{ user: User; token: string }> {
    return safeFetch(
      "/auth/login",
      {
        method: "POST",
        body: JSON.stringify(credentials),
      },
      {
        user: {
          id: "u-101",
          email: credentials.email || "sinhvien@hub.edu.vn",
          name: credentials.email.split("@")[0] || "Sinh Viên Mẫu",
          createdAt: "2026-09-01T00:00:00Z",
        },
        token: "demo-jwt-token-ai-study-assistant",
      }
    );
  },

  // Lessons
  async getLessons(): Promise<Lesson[]> {
    return safeFetch<Lesson[]>("/lessons", { method: "GET" }, MOCK_LESSONS);
  },

  async getLessonById(id: string): Promise<Lesson> {
    const found = MOCK_LESSONS.find((l) => l.id === id) || {
      id,
      title: "Bài học mới",
      description: "Nội dung bài học được trích xuất từ tài liệu học tập.",
      topic: "Công nghệ thông tin",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      flashcardCount: 4,
      quizQuestionCount: 3,
      hasSummary: true,
      status: "ready",
    };
    return safeFetch<Lesson>(`/lessons/${id}`, { method: "GET" }, found);
  },

  async createLesson(payload: { title: string; description: string; topic: string; fileId?: string }): Promise<Lesson> {
    const newLesson: Lesson = {
      id: "lesson-" + Date.now(),
      title: payload.title,
      description: payload.description,
      topic: payload.topic,
      documentName: payload.fileId ? "Tai_lieu_hoc_tap.pdf" : undefined,
      documentSize: "1.8 MB",
      documentType: "application/pdf",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      flashcardCount: 5,
      quizQuestionCount: 3,
      hasSummary: true,
      status: "ready",
    };

    return safeFetch<Lesson>(
      "/lessons",
      {
        method: "POST",
        body: JSON.stringify(payload),
      },
      newLesson
    );
  },

  // File Upload
  async uploadDocument(file: File): Promise<UploadResponse> {
    const url = `${BASE_URL}/upload`;
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch(url, {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        throw new Error(`Upload thất bại với mã lỗi ${res.status}`);
      }
      return await res.json();
    } catch (err: any) {
      console.warn("[Upload] Backend upload offline, kích hoạt mock response.");
      return {
        fileId: "file-" + Date.now(),
        fileName: file.name,
        fileSize: file.size,
        extractedTextLength: 4500,
        message: "Tải tài liệu và trích xuất thành công (Mock Mode)",
      };
    }
  },

  // Summary
  async getLessonSummary(lessonId: string): Promise<SummaryData> {
    const fallback = MOCK_SUMMARIES[lessonId] || {
      lessonId,
      overview: "Tóm tắt tự động bài học được sinh bởi mô hình AI dựa trên tài liệu đã tải lên.",
      keyPoints: [
        "Khái niệm cốt lõi được hệ thống phân tách rõ ràng theo từng phần.",
        "Mô hình dữ liệu và các quy tắc logic quan trọng cần nắm vững.",
        "Ứng dụng thực tiễn trong các bài thi và dự án học kỳ.",
      ],
      takeaways: [
        "Ôn tập kỹ phần định nghĩa và cấu trúc cơ bản trước khi làm quiz.",
        "Liên kết kiến thức bài học này với các chương tiếp theo.",
      ],
      generatedAt: new Date().toISOString(),
    };

    return safeFetch<SummaryData>(`/lessons/${lessonId}/summary`, { method: "GET" }, fallback);
  },

  // Flashcards
  async getLessonFlashcards(lessonId: string): Promise<Flashcard[]> {
    const fallback = MOCK_FLASHCARDS[lessonId] || [
      {
        id: "fc-def-1",
        lessonId,
        term: "Thuật ngữ 1",
        definition: "Định nghĩa chi tiết về khái niệm cốt lõi của bài học.",
        difficulty: "easy",
      },
      {
        id: "fc-def-2",
        lessonId,
        term: "Thuật ngữ 2",
        definition: "Cách áp dụng thuật ngữ trong tình huống thực tế.",
        difficulty: "medium",
      },
    ];

    return safeFetch<Flashcard[]>(`/lessons/${lessonId}/flashcards`, { method: "GET" }, fallback);
  },

  // Quiz
  async getLessonQuiz(lessonId: string): Promise<QuizQuestion[]> {
    const fallback = MOCK_QUIZZES[lessonId] || [
      {
        id: "q-default-1",
        lessonId,
        question: "Đâu là đặc điểm quan trọng nhất của bài học này?",
        options: ["Đáp án A chuẩn xác", "Đáp án B chưa đủ ý", "Đáp án C không liên quan", "Đáp án D sai hoàn toàn"],
        correctIndex: 0,
        explanation: "Đáp án A thể hiện đầy đủ nhất theo nội dung tài liệu học phần.",
      },
      {
        id: "q-default-2",
        lessonId,
        question: "Bước đầu tiên trong quy trình xử lý là gì?",
        options: ["Khởi tạo và cấu hình", "Kiểm thử đầu ra", "Tối ưu hóa tài nguyên", "Đóng kết nối"],
        correctIndex: 0,
        explanation: "Cần khởi tạo cấu hình trước khi xử lý các nghiệp vụ khác.",
      },
    ];

    return safeFetch<QuizQuestion[]>(`/lessons/${lessonId}/quiz`, { method: "GET" }, fallback);
  },

  // Submit Quiz
  async submitQuiz(submission: QuizSubmission): Promise<QuizResult> {
    const fallback: QuizResult = {
      lessonId: submission.lessonId,
      totalQuestions: submission.answers.length || 3,
      correctAnswers: submission.answers.filter((a) => a.selectedIndex === 0 || a.selectedIndex === 2).length,
      scorePercentage: Math.round(
        (submission.answers.filter((a) => a.selectedIndex === 0 || a.selectedIndex === 2).length /
          (submission.answers.length || 1)) *
          100
      ),
      feedback: "Làm bài rất tốt! Bạn đã nắm vững các khái niệm trọng tâm.",
      details: submission.answers.map((a) => ({
        questionId: a.questionId,
        isCorrect: a.selectedIndex === 0 || a.selectedIndex === 2,
        correctIndex: 0,
        selectedIndex: a.selectedIndex,
        explanation: "Kiểm tra kiến thức cốt lõi theo giáo trình chuẩn.",
      })),
    };

    return safeFetch<QuizResult>(
      `/lessons/${submission.lessonId}/quiz/submit`,
      {
        method: "POST",
        body: JSON.stringify(submission),
      },
      fallback
    );
  },

  // Smart Context Knowledge Chunks
  async getLessonSmartContext(lessonId: string): Promise<SmartContextData> {
    const fallback: SmartContextData = MOCK_CONTEXTS[lessonId] || {
      lessonId,
      tokenUsed: 420,
      tokenLimit: 4000,
      latencyMs: 45,
      guardrailActive: true,
      chunks: [
        {
          id: `chunk-${lessonId}-1`,
          lessonId,
          title: "Chunk #01 • Định nghĩa & Khái niệm",
          content: "Nội dung trích xuất từ tài liệu học tập: các định lý, công thức và nguyên lý vận hành nền tảng.",
          similarityScore: 0.92,
          source: "Tài liệu giáo trình (PDF)",
          charCount: 210,
        },
        {
          id: `chunk-${lessonId}-2`,
          lessonId,
          title: "Chunk #02 • Ví dụ & Ứng dụng",
          content: "Phân tích ví dụ mẫu và trường hợp áp dụng thực tế trong đề thi và bài tập lớn.",
          similarityScore: 0.85,
          source: "Slide bài giảng",
          charCount: 195,
        },
      ],
    };

    return safeFetch<SmartContextData>(`/lessons/${lessonId}/context`, { method: "GET" }, fallback);
  },

  // AI Tutor Chat with Grounding & 3 Modes
  async sendChatMessage(payload: {
    lessonId?: string;
    question: string;
    tutorMode?: TutorMode;
    history?: ChatMessage[];
  }): Promise<{
    answer: string;
    citations?: string[];
    isGuardrailHit?: boolean;
    matchedChunkIds?: string[];
    tokensUsed?: number;
  }> {
    const q = payload.question.toLowerCase();
    const mode = payload.tutorMode || "easy";

    // Anti-Hallucination Guardrail Check for Mock Fallback
    const isOutOfScope = q.includes("2nf") || q.includes("chuẩn hóa") || q.includes("nấu phở") || q.includes("ngoài bài");

    let fallbackAnswer = "";
    let fallbackCitations: string[] = [];
    let matchedChunkIds: string[] = [];

    if (isOutOfScope) {
      fallbackAnswer = `🛡️ [Phát hiện thông tin ngoài bài học]:\nMình đã quét toàn bộ Smart Context của bài học và không tìm thấy nội dung nào liên quan đến "${payload.question}".\n\nTheo nguyên tắc chống ảo giác của AI Study Assistant, mình không được tự bịa nội dung ngoài giáo trình. Bạn có muốn mình tra cứu mở rộng bên ngoài bài học không?`;
      fallbackCitations = ["Trạng thái: 0 chunks phù hợp trong Knowledge Base bài học"];
    } else if (q.includes("công thức") || q.includes("lambda")) {
      fallbackAnswer = `📐 [Công thức Phân phối Poisson]:\nXác suất để có đúng k lần sự kiện xảy ra là: P(X = k) = (e^(-λ) · λ^k) / k!\n\n• λ (Lambda): Tốc độ trung bình biến cố xuất hiện trong một khoảng xác định.\n• e: Số Euler xấp xỉ 2.71828.\n• Điểm then chốt: Cả Kỳ vọng E(X) = λ và Phương sai Var(X) = λ!`;
      fallbackCitations = ["Slide 4 & Slide 5 (Độ tin cậy: 94%)"];
      matchedChunkIds = ["chunk-poisson-2", "chunk-poisson-1"];
    } else if (q.includes("kiểm tra")) {
      fallbackAnswer = `🎯 [Câu hỏi kiểm tra 1-1 nhanh dành cho bạn]:\nGiả sử trung bình có λ = 4 xe qua trạm thu phí mỗi phút. Điều kiện nào là BẮT BUỘC để áp dụng được phân phối Poisson?\n\nA. Các xe phải cách đều nhau đúng 15 giây.\nB. Các xe đến hoàn toàn độc lập với nhau và tốc độ trung bình λ không đổi.\nC. Chỉ áp dụng cho ban ngày.\n\n(Hãy gõ A, B hoặc C để mình chấm điểm và giải thích ngay nhé!)`;
      fallbackCitations = ["Slide 4 • Mục điều kiện độc lập"];
      matchedChunkIds = ["chunk-poisson-1"];
    } else {
      if (mode === "easy") {
        fallbackAnswer = `💡 [Giảng lại Đời thường cho bạn mất gốc]:\nTưởng tượng bạn đang đợi xe buýt: Trung bình cứ 10 phút thì có 1 xe chạy qua (λ = 1). Nhưng thực tế có lúc đợi 10 phút chẳng có xe nào, có lúc 2 xe cùng tới.\n👉 Phân phối Poisson giúp bạn tính chính xác xác suất: "Khả năng có đúng 2 xe tới trong 10 phút là bao nhiêu %?".\nQuy tắc vàng: Các xe chạy độc lập, không ảnh hưởng lẫn nhau!`;
      } else if (mode === "standard") {
        fallbackAnswer = `📘 [Giảng lại theo Chuẩn giáo trình]:\nPhân phối Poisson là phân phối xác suất rời rạc biểu diễn số lần xảy ra của một sự kiện trong một khoảng thời gian/không gian nhất định.\n• Tham số đặc trưng duy nhất: λ > 0 (vừa là kỳ vọng vừa là phương sai).\n• Ứng dụng: Đếm số cuộc gọi đến tổng đài, số lỗi in trên 1 trang sách, số lượt truy cập web.`;
      } else {
        fallbackAnswer = `🔬 [Phân tích Chuyên sâu (Advanced & Thi cử)]:\nPoisson thực chất là dạng xấp xỉ của Phân phối Nhị thức B(n, p) khi số phép thử n rất lớn (n > 50) và xác suất p rất nhỏ (p < 0.05) sao cho tích np = λ = hằng số.\n• Trong đề thi, khi gặp bài toán n lớn và p rất nhỏ, luôn nhớ đổi sang xấp xỉ Poisson để tính nhanh!`;
      }
      fallbackCitations = ["Slide 4 & Audio 04:12 (Độ tin cậy: 92%)"];
      matchedChunkIds = ["chunk-poisson-1", "chunk-poisson-3"];
    }

    return safeFetch<{
      answer: string;
      citations?: string[];
      isGuardrailHit?: boolean;
      matchedChunkIds?: string[];
      tokensUsed?: number;
    }>(
      "/chat",
      {
        method: "POST",
        body: JSON.stringify(payload),
      },
      {
        answer: fallbackAnswer,
        citations: fallbackCitations,
        isGuardrailHit: isOutOfScope,
        matchedChunkIds,
        tokensUsed: Math.floor(Math.random() * 50) + 420,
      }
    );
  },
};
