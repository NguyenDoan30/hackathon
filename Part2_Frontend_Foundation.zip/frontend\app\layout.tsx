import type { Metadata } from "next";
import "./globals.css";
import Navbar from "../components/Navbar";

export const metadata: Metadata = {
  title: "AI Study Assistant - Trợ Lý Học Tập Thông Minh",
  description: "Hệ thống hỗ trợ học tập thông minh: Tóm tắt bài học, tạo Flashcard, Quiz trắc nghiệm và Chatbot AI Tutor.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="vi">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </head>
      <body>
        <Navbar />
        <main style={{ minHeight: "calc(100vh - 75px)", padding: "28px 20px" }}>
          {children}
        </main>
      </body>
    </html>
  );
}
