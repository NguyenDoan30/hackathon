export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  createdAt: string;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  topic: string;
  documentName?: string;
  documentSize?: string;
  documentType?: string;
  createdAt: string;
  updatedAt: string;
  flashcardCount: number;
  quizQuestionCount: number;
  hasSummary: boolean;
  status: "ready" | "processing" | "failed";
}

export interface SummaryData {
  lessonId: string;
  overview: string;
  keyPoints: string[];
  takeaways: string[];
  mindmapOutline?: string[];
  generatedAt: string;
}

export interface Flashcard {
  id: string;
  lessonId: string;
  term: string;
  definition: string;
  category?: string;
  difficulty?: "easy" | "medium" | "hard";
  isMastered?: boolean;
}

export interface QuizQuestion {
  id: string;
  lessonId: string;
  question: string;
  options: string[];
  correctIndex: number; // 0-based
  explanation: string;
}

export interface QuizSubmission {
  lessonId: string;
  answers: { questionId: string; selectedIndex: number }[];
}

export interface QuizResult {
  lessonId: string;
  totalQuestions: number;
  correctAnswers: number;
  scorePercentage: number;
  feedback: string;
  details: {
    questionId: string;
    isCorrect: boolean;
    correctIndex: number;
    selectedIndex: number;
    explanation: string;
  }[];
}

export interface ContextChunk {
  id: string;
  lessonId: string;
  title: string;
  content: string;
  similarityScore: number;
  source: string;
  charCount: number;
  isHighlighted?: boolean;
}

export type TutorMode = "easy" | "standard" | "advanced";

export interface ChatMessage {
  id: string;
  sender: "user" | "ai";
  text: string;
  timestamp: string;
  sourceCitations?: string[];
  tutorMode?: TutorMode;
  isGuardrailHit?: boolean;
  tokenCost?: number;
  matchedChunkIds?: string[];
}

export interface SmartContextData {
  lessonId: string;
  tokenUsed: number;
  tokenLimit: number;
  latencyMs: number;
  guardrailActive: boolean;
  chunks: ContextChunk[];
}

export interface UploadResponse {
  fileId: string;
  fileName: string;
  fileSize: number;
  extractedTextLength: number;
  message: string;
}
