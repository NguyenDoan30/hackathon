"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const [userName, setUserName] = useState<string>("Sinh Viên");

  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("user");
      if (stored) {
        try {
          const u = JSON.parse(stored);
          if (u.name) setUserName(u.name);
        } catch (e) {}
      }
    }
  }, []);

  const handleLogout = () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("user");
      localStorage.removeItem("token");
    }
    router.push("/login");
  };

  // Don't render navigation on login page
  if (pathname === "/login") {
    return null;
  }

  const navLinks = [
    { label: "Trang chủ", href: "/home", icon: "📚" },
    { label: "Tạo bài học", href: "/create", icon: "✨" },
    { label: "Tải tài liệu", href: "/upload", icon: "📤" },
  ];

  return (
    <header style={{
      position: "sticky",
      top: 0,
      zIndex: 50,
      background: "rgba(13, 15, 23, 0.85)",
      backdropFilter: "blur(16px)",
      borderBottom: "1px solid var(--surface-border)",
      padding: "14px 28px",
    }}>
      <div style={{
        maxWidth: "1280px",
        margin: "0 auto",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}>
        {/* Brand */}
        <Link href="/home" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <div style={{
            width: "38px",
            height: "38px",
            borderRadius: "10px",
            background: "linear-gradient(135deg, var(--primary) 0%, var(--accent-cyan) 100%)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "1.2rem",
            boxShadow: "0 0 16px var(--primary-glow)",
          }}>
            ⚡
          </div>
          <div>
            <div style={{ fontSize: "1.15rem", fontWeight: 800, letterSpacing: "-0.01em" }}>
              AI <span style={{ color: "var(--accent-cyan)" }}>Study Assistant</span>
            </div>
            <div style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>Học tập thông minh cùng trợ lý AI</div>
          </div>
        </Link>

        {/* Navigation Links */}
        <nav style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          {navLinks.map((link) => {
            const isActive = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  padding: "8px 14px",
                  borderRadius: "var(--radius-sm)",
                  fontSize: "0.9rem",
                  fontWeight: isActive ? 600 : 500,
                  color: isActive ? "#ffffff" : "var(--text-sub)",
                  background: isActive ? "rgba(99, 102, 241, 0.2)" : "transparent",
                  border: isActive ? "1px solid rgba(99, 102, 241, 0.4)" : "1px solid transparent",
                  transition: "var(--transition-fast)",
                }}
              >
                <span>{link.icon}</span>
                <span>{link.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* User Profile & Actions */}
        <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
          <div style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
            padding: "6px 12px",
            background: "rgba(255, 255, 255, 0.04)",
            borderRadius: "var(--radius-md)",
            border: "1px solid var(--surface-border)",
          }}>
            <div style={{
              width: "28px",
              height: "28px",
              borderRadius: "50%",
              background: "linear-gradient(135deg, var(--secondary) 0%, #ec4899 100%)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "0.8rem",
              fontWeight: "bold",
            }}>
              {userName.charAt(0).toUpperCase()}
            </div>
            <span style={{ fontSize: "0.85rem", fontWeight: 600, color: "var(--text-sub)" }}>
              {userName}
            </span>
          </div>

          <button
            onClick={handleLogout}
            title="Đăng xuất"
            style={{
              background: "rgba(244, 63, 94, 0.12)",
              color: "#fb7185",
              border: "1px solid rgba(244, 63, 94, 0.3)",
              padding: "7px 12px",
              borderRadius: "var(--radius-sm)",
              fontSize: "0.8rem",
              fontWeight: 600,
              cursor: "pointer",
              transition: "var(--transition-fast)",
            }}
          >
            Đăng xuất
          </button>
        </div>
      </div>
    </header>
  );
}
