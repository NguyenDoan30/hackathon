# 🎓 AI STUDY ASSISTANT — HỆ THỐNG TRỢ LÝ HỌC TẬP THÔNG MINH

> **Slogan:** *"Ghi lại một lần — Hiểu bài cả kỳ"*  
> Hệ thống học tập cá nhân hóa ứng dụng AI: Đa phương thức đầu vào (PDF, OCR Slide, Audio Whisper) $\to$ Smart Context RAG $\to$ AI Tutor bám sát giáo trình $\to$ Tự động sinh Sơ đồ tư duy, Flashcards & Quiz ôn tập.

---

## 🌟 Tính Năng Nổi Bật

1. **🛡️ Smart Context & Chống Ảo Giác (Anti-Hallucination Grounding):**
   - Phân đoạn tài liệu thông minh (Semantic Chunking) và tính toán độ tương đồng ngữ nghĩa (Cosine Vector Similarity).
   - Ép buộc AI Tutor chỉ giải thích trong phạm vi ngữ cảnh bài học và đính kèm trích dẫn nguồn (Citations). Nếu câu hỏi nằm ngoài giáo trình, AI sẽ từ chối lịch sự và trung thực học thuật, không tự ý bịa đặt.
2. **👨‍🏫 AI Tutor Đa Cấp Độ (3 Chế Độ Giảng Dạy):**
   - **💡 Dễ hiểu (Cho bạn mất gốc):** Giảng giải bằng các ví dụ đời thường gần gũi, trực quan.
   - **📘 Chuẩn giáo trình:** Đầy đủ định nghĩa, công thức toán học, kỳ vọng và phương sai.
   - **🔬 Chuyên sâu & Kiểm tra tư duy 1-1:** Phân tích bản chất học thuật chuyên sâu và tự động đặt câu hỏi trắc nghiệm kiểm tra tư duy trực tiếp.
3. **📊 Thước Đo Hiệu Năng & Ngữ Cảnh:**
   - Theo dõi thời gian thực dung lượng Prompt (Context Token Budget: `482 / 4,000 tokens`).
   - Tốc độ truy xuất vector siêu tốc (`42 ms ⚡`).
4. **🧠 Tự Động Sinh Công Cụ Học Tập:**
   - Sơ đồ tư duy phân cấp (Mindmap Outline).
   - Bộ thẻ ghi nhớ lặp lại ngắt quãng (Flashcards Spaced Repetition).
   - Trắc nghiệm tính điểm tự động kèm giải thích chi tiết (Quiz Runner).
5. **🛡️ Chế Độ Hybrid Thông Minh (Offline-Ready):**
   - Tự động kết nối Backend API thật khi server hoạt động.
   - Tự động kích hoạt Smart Mock Engine khi ngoại tuyến, bảo đảm ứng dụng luôn sẵn sàng demo mọi lúc mọi nơi.

---

## 🤝 Phân Định Kiến Trúc Nhóm 5 Người (Zero Merge Conflict)

Để 5 thành viên có thể lập trình độc lập đồng thời trên Git mà không bao giờ bị xung đột mã nguồn:

| Thành Viên | Phụ Trách | Phạm Vi Thư Mục / Nhiệm Vụ | Đầu Ra Chuẩn |
| :--- | :--- | :--- | :--- |
| **Phần 1** | **Frontend / UI** | `frontend/` (Giao diện web, Next.js, components, types, services) | Giao diện chạy mượt mà, đầy đủ tính năng, gọi đúng API |
| **Phần 2** | **Backend / Database** | `backend/database.py`, `backend/main.py`, `backend/models.py` | FastAPI server, SQLite lưu bài học, Swagger docs `/docs` |
| **Phần 3** | **AI / Smart Context** | `backend/ai_engine/` (RAG, Gemini/Groq, prompts, chunks indexing) | Module AI độc lập, trả lời có grounding & trích nguồn |
| **Phần 4** | **File Processing** | Xử lý dữ liệu đầu vào: PDF Parser, Vision/OCR, Speech-to-Text Whisper | Chuyển đổi Slide, ảnh chụp, file ghi âm $\to$ văn bản sạch |
| **Phần 5** | **Learning & Testing** | Logic chấm điểm Quiz, quản lý Flashcards, theo dõi tiến độ & Test suite | Chấm điểm, đánh giá kiến thức mạnh/yếu, bộ test MVP |

---

## 📁 Cấu Trúc Dự Án

```
hackathon/
├── index.html                    # Bản Web Client hoàn chỉnh (chạy ngay trên trình duyệt)
├── README.md                     # Tài liệu kiến trúc và hướng dẫn dự án
│
├── frontend/                     # MODULE FRONTEND (Next.js + TypeScript)
│   ├── app/
│   │   ├── globals.css           # Bảng màu, typography Inter, glassmorphism
│   │   ├── layout.tsx            # Root layout & Navbar
│   │   ├── home/page.tsx         # Dashboard bài học, tìm kiếm, tiến độ
│   │   └── lesson/[id]/page.tsx  # Không gian học tập: Tóm tắt, Mindmap, Flashcard, Quiz & AI Tutor
│   ├── components/
│   │   ├── SmartContextInspector.tsx  # Bảng điều khiển RAG Chunks, Guardrail, Token Budget
│   │   ├── ChatBox.tsx                # AI Tutor đa chế độ, Citations hai chiều, Ghi âm Web Audio
│   │   ├── SummaryViewer.tsx          # Hiển thị tóm tắt & sơ đồ phân cấp
│   │   ├── FlashcardDeck.tsx          # Bộ thẻ lật 3D ghi nhớ
│   │   └── QuizRunner.tsx             # Trắc nghiệm tính điểm & giải thích
│   ├── services/
│   │   └── api.ts                # Client gọi API Backend + Chế độ Smart Mock dự phòng
│   └── types/
│       └── index.ts              # Interface chuẩn: Lesson, ContextChunk, SmartContextData
│
└── backend/                      # MODULE BACKEND (Python FastAPI)
    ├── database.py               # Kết nối SQLite & dữ liệu khởi tạo
    ├── main.py                   # FastAPI REST API endpoints
    ├── models.py                 # Pydantic schemas
    └── ai_engine/                # Bộ não AI / Smart Context độc lập
        ├── smart_context.py      # Semantic chunking & Vector cosine similarity
        ├── tutor_engine.py       # Multi-level persona & Anti-hallucination logic
        └── artifacts_generator.py# Tự động sinh Summary, Mindmap, Flashcard, Quiz
```

---

## 🚀 Hướng Dẫn Khởi Động Nhanh

### Cách 1: Chạy Bản Web Client Trực Tiếp (Không Cần Cài Đặt)
- Mở trực tiếp file `index.html` bằng trình duyệt Chrome hoặc Edge để trải nghiệm toàn bộ tính năng giao diện và Smart Context.
- Hoặc bật tính năng **GitHub Pages** (Settings $\to$ Pages $\to$ chọn nhánh `main`) để xem online.

### Cách 2: Khởi Động Đầy Đủ Fullstack
1. **Khởi động Backend (FastAPI):**
   ```bash
   cd backend
   pip install -r requirements.txt
   uvicorn main:app --reload --port 8000
   ```
   - API Docs Swagger: `http://localhost:8000/docs`

2. **Khởi động Frontend (Next.js):**
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
   - Truy cập giao diện tại: `http://localhost:3000`
